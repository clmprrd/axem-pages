---
name: comparer-des-prestataires
description: Compare plusieurs offres de prestataires (outils de calcul carbone, auditeurs RSE, plateformes de reporting) sur une grille de critères pondérés écrite une fois, avec une note justifiée et citée par critère, un classement, et un refaire-le-classement quand un critère ou un poids change. À utiliser dès que l'utilisateur veut comparer, choisir ou classer des offres, des devis, des outils ou des fournisseurs.
---

# Comparer des prestataires sur une grille écrite une fois

La grille est écrite avant de regarder les offres, puis elle ne bouge plus sans décision de l'utilisateur. Chaque note se justifie avec une citation de l'offre.

## Règles qui ne bougent pas

- La grille (critères, poids, échelle) est fixée et validée par l'utilisateur avant la notation.
- Chaque note est accompagnée d'une justification qui cite l'offre : `[offre B, p. 3]`. Pas de citation, pas de note : écris `non évaluable` et explique ce qui manque.
- Ne jamais inventer une caractéristique, un tarif ou une référence. Si l'offre ne dit rien, c'est `non précisé`, et la note reste la plus basse de l'échelle ou `non évaluable` selon ce que la grille a prévu.
- Le classement est une aide. L'utilisateur décide.

## Méthode

### 1. Écrire la grille
Avec l'utilisateur, fixe 5 à 10 critères, un poids par critère (total 100) et une échelle de 0 à 5 avec ce que signifie chaque niveau pour les critères importants.

| Critère | Poids | 0 | 3 | 5 |
|---|---|---|---|---|
| Couverture des exigences | 30 | rien | partielle | complète |

Exemples de critères : couverture fonctionnelle, méthode et référentiels reconnus, export des données, sécurité et hébergement, accompagnement, délais, références, coût total sur la durée.

### 2. Lire chaque offre
Pour chaque offre, extrais les faits utiles par critère avec leur source.

### 3. Noter
Tableau : offre, critère, note, justification citée. Calcule le score pondéré : somme (note ÷ 5 × poids). Montre le calcul.

### 4. Classer
Classement du premier au dernier avec le score sur 100, les deux forces et les deux faiblesses de chaque offre, et les points à clarifier auprès du prestataire.

### 5. Refaire le classement quand quelque chose change
Quand un critère, un poids ou une note change :
1. Écris la modification et qui l'a demandée.
2. Recalcule tout.
3. Montre ce qui a bougé : ancien rang → nouveau rang, ancien score → nouveau score.
4. Explique pourquoi en une phrase (par exemple : « le poids du critère Export passe de 10 à 25, l'offre C remonte car elle exporte au format ouvert [offre C, p. 5] »).
Garde l'historique des versions de la grille.

## Format de sortie

1. La grille validée (critères, poids, échelle), datée.
2. Le tableau des notes avec justifications citées.
3. Le classement avec les scores et le calcul.
4. Les questions à poser à chaque prestataire.
5. Si la grille a changé : le tableau « ce qui a bougé ».

## Pièges à éviter

- Ne pas comparer un prix annuel et un prix sur trois ans : ramène tout à la même base avant de noter, et écris la base.
- Ne pas laisser un critère sans poids « pour voir » : un critère sans poids n'existe pas.
- Ne pas noter sur la réputation. Seul ce qui est écrit dans l'offre ou fourni par l'utilisateur compte.

## Exemple fictif

**Entrée :** « Compare ces trois outils de calcul carbone (A, B, C). Critères : couverture des émissions indirectes 40, export des données 20, prix sur trois ans 40. »

**Sortie (extrait) :**
- Outil A : couverture 4/5 « tous les postes du protocole » [A, p. 2] ; export 2/5 « PDF uniquement » [A, p. 6] ; prix 3/5. Score : 62 sur 100.
- Classement : 1. B (74), 2. A (62), 3. C (51).
- Changement : le poids de l'export passe de 20 à 40, celui du prix de 40 à 20. Nouveau classement : 1. B (78), 2. C (60), 3. A (56). A perd une place car il n'exporte qu'en PDF [A, p. 6].

---
Skill préparé par AXEM IA (axem-ia.fr)
