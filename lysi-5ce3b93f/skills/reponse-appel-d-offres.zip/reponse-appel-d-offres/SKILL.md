---
name: reponse-appel-d-offres
description: Prépare la réponse à un appel d'offres (marché de conseil RSE, CSRD, VSME, bilan carbone, EcoVadis) en 7 étapes, de la fiche de l'appel d'offres au dépôt et aux rappels. À utiliser dès que l'utilisateur parle d'un appel d'offres, d'un cahier des charges, d'un dossier de candidature, d'un marché public ou d'une consultation à laquelle il faut répondre.
---

# Répondre à un appel d'offres

Tu prépares la réponse, l'équipe décide. Tu ne déposes rien et tu ne tranches jamais seul la décision d'y aller.

## Règles qui ne bougent pas

- Ne jamais inventer une référence client, un chiffre, une certification ou un CV. Si l'information n'est pas fournie par l'utilisateur ou présente dans les documents, écris `[À COMPLÉTER]` à la place.
- Chaque affirmation du mémoire s'appuie sur une pièce fournie ou sur le cahier des charges. Sinon, `[À COMPLÉTER]`.
- La décision d'y aller ou non appartient à l'équipe. Tu présentes les faits et un avis argumenté, rien de plus.
- Les dates limites sont recopiées telles qu'écrites dans le règlement de consultation, avec la page.

## Les 7 étapes

### 1. Fiche de l'appel d'offres (une page)
Demande ou lis le règlement et le cahier des charges. Remplis : acheteur, objet, lots, montant estimé s'il est donné, durée, date limite de remise, date de questions, mode de dépôt, langue, critères de jugement et leur poids, variantes autorisées ou non.

### 2. Lecture détaillée du cahier des charges
Relis tout. Produis le tableau **exigence → où on y répond** :

| N° | Exigence (citée, avec page) | Type (obligatoire / noté / information) | Où on y répond | Statut |

Signale les clauses à risque : pénalités, exclusivité, propriété des livrables, assurance, délais courts, références exigées que l'équipe n'a peut-être pas.

### 3. Dossier monté (pièces administratives)
Liste toutes les pièces demandées : formulaires, attestations fiscales et sociales, extrait d'immatriculation, assurance, déclarations sur l'honneur, pouvoirs du signataire. Pour chacune : fournie / à demander / à produire, avec le nom du responsable et la date.

### 4. Réponse rédigée (une note par partie)
Une note par partie du dossier (compréhension du besoin, méthode, équipe, planning, références, prix si demandé à part). Chaque note : reprend les mots de l'acheteur, répond aux critères notés dans l'ordre de leur poids, ne dépasse pas la limite de pages. Les passages sans matière sont marqués `[À COMPLÉTER]`.

### 5. Décision d'y aller par l'équipe (go / no-go)
Prépare une page de décision : adéquation avec nos offres, charge de travail estimée, références disponibles, concurrents probables si connus, risques, points `[À COMPLÉTER]` restants. Termine par : « Avis de Claude : … (à confirmer par l'équipe) ». Attends la réponse humaine avant de poursuivre le dépôt.

### 6. Dépôt du dossier
Prépare la liste finale : format des fichiers, nommage demandé, taille maximale, signature, plateforme de dépôt. Rappelle que le dépôt est figé une fois fait. C'est l'équipe qui dépose.

### 7. Rappels
Propose des rappels à J-15, J-7 et J-2 avant la date limite, avec pour chacun ce qui doit être fini à cette date (par exemple J-15 : questions posées et pièces demandées ; J-7 : mémoire relu ; J-2 : dossier complet et testé sur la plateforme).

## Sorties attendues

1. **La checklist** d'environ 29 tâches (dans l'exemple ci-dessous : 20 préparées par Claude, 9 décisions gardées par l'équipe), classées par étape, avec responsable et date.
2. **Le tableau exigence → où on y répond**.
3. **Le mémoire technique**, une note par partie.

## Exemple fictif

**Entrée :** « Voici le cahier des charges d'une consultation de la société Exemple pour un accompagnement CSRD, remise dans 25 jours. Prépare la réponse. »

**Sortie (extrait) :**
- Fiche : acheteur Exemple SA, objet : accompagnement CSRD sur 12 mois, remise le 14, critères : valeur technique 60 %, prix 30 %, délais 10 %.
- Exigence 7 (p. 12) : « trois références de moins de 3 ans » → partie Références. Statut : `[À COMPLÉTER]`, aucune référence fournie.
- Checklist (exemple illustratif) : Claude a découpé la réponse en 29 tâches. Claude en prépare 20 (fiche, lecture, tableau des exigences, pièces à réunir, notes du mémoire, rappels) ; l'équipe garde les 9 décisions (go / no-go, prix, choix des références, relecture finale, signature, dépôt, etc.).
- Page go / no-go : « Avis de Claude : go sous réserve des références (à confirmer par l'équipe). »

---
Skill préparé par AXEM IA (axem-ia.fr)
