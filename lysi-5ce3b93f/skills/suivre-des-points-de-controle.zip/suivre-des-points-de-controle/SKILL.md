---
name: suivre-des-points-de-controle
description: Tient une grille de points de contrôle par client (par exemple les points à prouver avant une évaluation EcoVadis) avec un statut prêt, en cours ou ne concerne pas ce client, la preuve attendue et le responsable, la met à jour à partir des documents reçus et liste ce qui manque avant l'échéance. À utiliser dès que l'utilisateur veut suivre un dossier client, faire le point sur des preuves, préparer une évaluation ou une certification, ou mettre à jour une grille.
---

# Suivre des points de contrôle par client

Une grille par client. Chaque ligne est un point à prouver. Un point est « prêt » seulement si la preuve est dans les documents reçus.

## Règles qui ne bougent pas

- Trois statuts seulement : `prêt`, `en cours`, `ne concerne pas ce client`.
- Un point passe à `prêt` uniquement si tu as lu un document qui le prouve. Tu cites le document et le passage. Sans preuve lue, le point reste `en cours`.
- Un point passe à `ne concerne pas ce client` seulement avec la raison écrite et validée par l'utilisateur.
- Ne jamais inventer une preuve, une date ou un responsable. Inconnu : `[À COMPLÉTER]`.
- Une grille par client : ne mélange jamais les données de deux clients dans le même fichier.

## Structure de la grille

| N° | Point de contrôle | Statut | Preuve attendue | Preuve reçue (document, passage) | Responsable | Échéance | Note |
|---|---|---|---|---|---|---|---|

Les points viennent du référentiel de l'évaluation (par exemple les thèmes d'une évaluation de durabilité : environnement, social et droits humains, éthique, achats responsables) ou de la liste fournie par l'utilisateur.

## Méthode

### 1. Créer la grille
À partir du référentiel ou de la liste fournie, une ligne par point. Au départ, tous les points sont `en cours`, avec la preuve attendue décrite concrètement (par exemple : « politique achats responsables signée et datée »).

### 2. Attribuer
Pour chaque point : un responsable côté client et une échéance. Si l'utilisateur ne les donne pas, `[À COMPLÉTER]`.

### 3. Mettre à jour à partir des documents reçus
À chaque nouveau document :
1. Lis-le en entier.
2. Rattache-le aux points qu'il prouve. Cite le passage.
3. Vérifie que la preuve est datée, signée si nécessaire, et dans la période demandée.
4. Change le statut et écris la date de mise à jour.
Si le document ne prouve qu'une partie du point, le statut reste `en cours` et la note dit ce qui manque.

### 4. Liste de ce qui manque avant l'échéance
Après chaque mise à jour, produis :
- le compte : prêts, en cours, ne concernent pas ce client ;
- les points `en cours` classés par échéance, avec la preuve qui manque et le responsable ;
- les points sans responsable ou sans échéance ;
- les points en retard.

## Format de sortie

1. La grille à jour, avec la date de dernière mise à jour.
2. Le compte par statut.
3. La liste de ce qui manque avant l'échéance, triée par date.
4. En une ligne : ce qui a changé depuis la dernière version.

## Exemple fictif

**Entrée :** « Le client Exemple a envoyé sa politique achats (PDF, 3 pages). Mets à jour la grille avant l'évaluation du 30. »

**Sortie (extrait, exemple illustratif) :**
- Point 12, politique achats responsables : `prêt`. Preuve : « politique_achats.pdf, p. 3, signée et datée du 2 mars ».
- Point 13, évaluation des fournisseurs : reste `en cours`. La politique en parle [p. 2] mais aucune grille d'évaluation n'est jointe.
- Bilan sur 33 points : 4 prêts, 20 en cours, 9 qui ne concernent pas ce client (4 + 20 + 9 = 33).
- À fournir avant le 30 : grille d'évaluation des fournisseurs (responsable : directrice des achats), attestation de formation éthique (responsable : `[À COMPLÉTER]`).

---
Skill préparé par AXEM IA (axem-ia.fr)
