---
name: lire-et-resumer-un-document
description: Lit un document (rapport de durabilité, questionnaire VSME ou EcoVadis, contrat, politique, cahier des charges) et en tire un résumé court où chaque fait cite sa page ou sa ligne, avec les points faibles et ce qui n'est pas mesuré. À utiliser dès que l'utilisateur demande de lire, résumer, analyser ou relire un document, ou de repérer ce qui manque dedans.
---

# Lire et résumer un document, sans rien inventer

Le résumé doit pouvoir être vérifié en dix secondes : chaque fait renvoie à sa source dans le document. Un fait sans source n'a pas sa place.

## Règles qui ne bougent pas

- Jamais de fait sans source dans le document. Pas de connaissance générale, pas de supposition présentée comme un fait.
- Chaque fait porte sa référence entre crochets : `[p. 12]`, `[l. 34]`, `[section 3.2]`, `[question 14]`. Si le document n'a ni pages ni lignes, cite le titre de la section et les premiers mots du passage.
- Une citation exacte est mise entre guillemets et reste courte. Le reste est reformulé.
- Si une information n'est pas dans le document, dis-le : « Non précisé dans le document. »
- Si le document est illisible, tronqué ou scanné de façon partielle, signale-le en tête et indique ce qui n'a pas pu être lu.

## Méthode

### 1. Cadrer
Note le type de document, l'auteur ou l'émetteur s'il est écrit, la date, le périmètre couvert (entité, période, sites). Demande à l'utilisateur ce qu'il cherche si ce n'est pas clair : une décision, une conformité, une comparaison.

### 2. Lire en entier
Lis tout le document avant d'écrire. Relève les chiffres, les dates, les engagements, les exclusions, les définitions.

### 3. Écrire le résumé court
Trois à sept lignes. Chaque ligne : un fait, sa source. Pas d'adjectifs, pas d'avis mélangé aux faits.

### 4. Signaler les points faibles
Liste séparée, avec source : affirmations sans preuve, chiffres sans méthode de calcul, périmètre flou, objectifs sans date, incohérences entre deux passages (cite les deux).

### 5. Signaler ce qui n'est pas mesuré
Liste de ce qu'on s'attendrait à trouver pour ce type de document et qui n'apparaît pas (par exemple : une émission sans année de référence, un engagement sans indicateur). Précise bien qu'il s'agit d'une absence constatée dans ce document, pas d'une erreur de l'auteur.

### 6. Questions à poser
Trois questions maximum à poser à l'émetteur pour lever les doutes.

## Format de sortie

```
Document : <type, émetteur, date, périmètre>
Résumé
- <fait> [source]
Points faibles
- <point> [source]
Non mesuré / absent
- <élément attendu> : non trouvé
Questions
1. ...
```

## Exemple fictif

**Entrée :** « Résume ce rapport de durabilité de 40 pages. » (rapport d'une entreprise fictive)

**Sortie (extrait) :**
Document : rapport de durabilité, société Exemple, exercice 2024, périmètre : siège et deux usines.
Résumé
- Émissions de gaz à effet de serre annoncées en baisse de 12 % entre 2022 et 2024 [p. 18].
- Objectif de neutralité à 2040 [p. 4].
Points faibles
- La baisse de 12 % n'indique pas si les émissions indirectes sont incluses [p. 18].
Non mesuré / absent
- Aucun indicateur sur les fournisseurs : non trouvé.
Questions
1. Quelle est la méthode de calcul de la baisse de 12 % ?

---
Skill préparé par AXEM IA (axem-ia.fr)
