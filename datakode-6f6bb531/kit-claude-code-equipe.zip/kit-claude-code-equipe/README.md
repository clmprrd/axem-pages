# Kit Claude Code d'équipe, offert par AXEM IA à Datakode

Trois fichiers, cinq minutes, aucun engagement.

| Fichier | Où le poser | Ce qu'il change |
|---|---|---|
| `CLAUDE.md` | racine du dépôt | tout le monde donne à Claude le même contexte et les mêmes interdits |
| `.claude/settings.json` | racine du dépôt (versionné) | Claude refuse de lire `.env`, les secrets et les exports de base, avec ses outils comme dans le terminal (`cat`, `head`, `grep`) ; `git push` et `curl` demandent une confirmation |
| `.gitlab/merge_request_templates/Claude-Code.md` | dans le dépôt GitLab | une case à cocher par règle, l'étiquette `ia` posée seule |

Source des réglages : https://code.claude.com/docs/en/settings

Pour une barrière au niveau du système (et pas seulement des règles), activez aussi le bac à sable de Claude Code : https://code.claude.com/docs/en/sandboxing
