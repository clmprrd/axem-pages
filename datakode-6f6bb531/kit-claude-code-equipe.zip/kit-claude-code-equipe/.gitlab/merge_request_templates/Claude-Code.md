## Ce que fait cette merge request
<!-- Deux lignes, dans les mots du client. -->

## Claude Code
- [ ] Une partie du code vient de Claude Code (étiquette `ia` posée)
- [ ] J'ai relu chaque ligne et je sais l'expliquer
- [ ] Aucune donnée réelle de client dans les prompts ni dans les tests
- [ ] Les tests passent en local
- [ ] Dépendance ajoutée : non / oui, laquelle et sa licence :

## Relu par
@

/label ~ia
