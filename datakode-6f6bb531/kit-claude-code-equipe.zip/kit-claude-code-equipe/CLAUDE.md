# Règles d'équipe pour Claude Code (Datakode)

> Ce fichier se pose à la racine de chaque dépôt GitLab. Claude Code le lit à chaque session :
> tout le monde travaille avec les mêmes règles, au lieu que chacun réexplique le projet à sa façon.
> À compléter ensemble : les lignes entre crochets sont à trancher en équipe.

## Le projet
- Nom et rôle : [ex. HYDRACLIC, gestion des points d'eau incendie pour les SDIS]
- Clients : [collectivités, SDIS, PME] ; données sensibles : [adresses, agents, données personnelles]
- Stack : Laravel (PHP), [front], [base de données], [cartographie]
- Lancer en local : `[commande]` ; lancer les tests : `php artisan test`

## Ce que Claude fait sans demander
- Lire le code, proposer un plan avant toute modification de plus de 3 fichiers.
- Écrire ou compléter les tests de ce qu'il modifie, puis les lancer.
- Respecter le style existant du fichier (nommage, commentaires, structure).

## Ce que Claude ne fait jamais
- Lire ou afficher un fichier `.env`, une clé, un mot de passe, un export de base client.
- Coller des données réelles d'un client dans une conversation : on travaille sur des données de test.
- Pousser sur `main` ou fusionner une merge request : un humain relit toujours.
- Ajouter une dépendance sans le dire dans la merge request (licence vérifiée, compatible open source).

## Qualité du code (décidée par l'équipe)
- Une merge request produite avec Claude Code porte l'étiquette `ia` et passe la même relecture qu'une autre.
- Pas de code que l'auteur ne sait pas expliquer en relecture.
- [Règle 3 à trancher en équipe]

## Vocabulaire Datakode
- On écrit pour nos clients dans les mots de nos clients : [lexique métier du projet].
