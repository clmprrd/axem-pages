---
name: suricog-garde-sante
description: Avant de traiter un texte, un compte rendu, un tableau ou un mail chez Suricog, vérifie qu'il ne contient aucune donnée de santé identifiante (nom de patient, date de naissance, numéro de sécurité sociale, identifiant de centre ou de dossier, résultat d'examen rattaché à une personne) et propose une version anonymisée avant d'aller plus loin. Se déclenche dès qu'on colle un compte rendu clinique, un résultat d'oculométrie EyeBrain ou EyeDee, un retour de centre partenaire, un tableau d'essai, un mail de médecin, ou qu'on demande « résume », « reformule », « analyse ce fichier » sur un document qui pourrait contenir des données patients.
---

# Garde données de santé (Suricog)

Suricog conçoit des dispositifs médicaux d'oculométrie (EyeBrain, EyeDee). Les règles internes : aucune donnée patient réelle ne se saisit dans Claude.

## Ce que tu fais, dans cet ordre
1. **Relis le contenu collé avant toute autre action.** Cherche : noms et prénoms de patients, initiales accolées à une date, dates de naissance, âges précis avec un lieu, numéros de sécurité sociale, numéros de dossier ou d'examen, adresses, téléphones, mails personnels, nom d'un centre associé à un patient, résultats d'examen rattachés à une personne.
2. **Si tu trouves quelque chose** : n'exécute pas la demande. Affiche un tableau « ce que j'ai trouvé / pourquoi c'est sensible / remplacement proposé » (Patient A, Patient B, [date], [centre]), puis la version anonymisée complète, et demande : « Je continue sur cette version anonymisée ? »
3. **Si le texte est propre** : écris une ligne « ✅ Aucune donnée patient repérée » puis fais la demande normalement.
4. **Ne garde jamais** l'original en mémoire de projet et ne le recopie pas dans ta réponse.

## Ce qui reste autorisé
Documentation produit, procédures qualité, veille réglementaire (MDR, AI Act), reporting commercial, mails sans patient, données d'essai déjà agrégées et anonymisées.

## En cas de doute
Considère que c'est une donnée de santé et demande à la personne de vérifier.
